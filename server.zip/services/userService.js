const knex = require("../db/knexConfig")

const userServ = {
    getUserByEmail(email) {
        return knex('users').select('*').where('email', email).first();
    },
    createUser(user) {
        return knex("users").insert(user);
    }
}
module.exports = userServ